document.querySelector("#grand").style.display="none";
document.querySelector("#petit").style.display="none";
document.querySelector("#bravo").style.display="none";
document.querySelector("#perdu").style.display="none";

var tentative=3;

document.querySelector("#tentative").innerHTML=tentative;

var nombre=parseInt(100*Math.random(100));

console.log(nombre);
