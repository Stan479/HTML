//  https://trankillprojets.fr/wal/

var mail; // mail utilisateur
var pseudo; // identite utilsateur
var id; // identifiant utilisateur
var pseudo_contacts = []; // identite des relations de l'utilisateur
var relation_contacts = []; // idantifiants de relations de l'utilisateur
var id_relation; //  id relation de la discussion actuelle
var discussion_initialise = false; // les discussion ont ete initialisé;
var connecter = false; //pour eviter d'afficher plusieur fois le pseudo si on click plusieur fois sur connecter
var id_discussions = []; // pour stocker les div discussion existantes

// clique sur un contact ouvre la discussion associer

document.getElementById("connecter").style.display = "none";
document.getElementById("co").style.display = "none";

function inscription() {
    document.getElementById('retour_inscription').innerHTML = "";
    mail =document.querySelector("#mail").value;
    pseudo = document.querySelector("#pseudo").value;
    fetch('https://trankillprojets.fr/wal/wal.php?inscription&identite='+pseudo+'&mail='+mail)
    .then(reponse => reponse.json())
    .then(json => {
     // {"etat" : { "reponse" : 1, "message" : "Un mail de validation vous a été envoyé"}}
     if(json.etat.reponse==1)
      {
        document.getElementById('retour_inscription').innerHTML = "Un mail de validation vous a été envoyé";
        console.log("inscription reussie");
    }
    else
      {
        document.getElementById('retour_inscription').innerHTML = "Cette adresse est incorecte ou déja utilisée ";
        console.log("inscription refusee");
      }
    })
    .catch(erreur => console.log(erreur)); // Le traitement a échoué (problème de réseau en général)
}

function connexion() {
        document.getElementById('retour_connexion').innerHTML = "";
        id = document.getElementById('id').value; // initialise id
        fetch('https://trankillprojets.fr/wal/wal.php?information&identifiant='+id)
        .then(reponse => reponse.json())
        .then(json => {
            if (json.etat.reponse && !connecter) {
            //{"etat" : { "reponse" : 1, "message" : "identification"}, "identite" : "...", "identifiant" : "...", "mail" : "..."}
                mail = json.mail; // initialise mail
                console.log("la connexion a reussi");
                pseudo = json.identite; // initialise pseudo
                document.getElementById("connecter").style.display = "block"; // affiche interface chat
                document.getElementById("con-ins").style.display = "none"; // cache interace connexion et inscrption
                document.getElementById("acceuil").innerHTML += pseudo;
                affiche_contact(); // affiche toutes les relations
                connecter = true;
            }
            else {
                document.getElementById('retour_connexion').innerHTML = "Identifiant incorrect";
                console.log("la connexion a echouee");
            }
        })
        .catch(erreur => console.log(erreur));
}
function add_contact() {
    let mail_contact = document.getElementById("new_contact").value;
    document.getElementById("reponse_new_contact").innerHTML = ""; // clear reponse_new_contact
    if (mail_contact == mail) {
        document.getElementById("reponse_new_contact").innerHTML = "Vous ne pouvez pas vous ajouter";
        return;
    }
    fetch('https://trankillprojets.fr/wal/wal.php?lier&identifiant='+ id +'&mail='+ mail_contact)
    .then(response => response.json())
    .then(json => {
        // {"etat" : { "reponse" : 1, "message" : "association OK"}}
        if (json.etat.reponse) {
            console.log("nouvelle relation confirmee");
            affiche_contact(); // reaffiche les relations (avec la nouvelle en plus)
            document.getElementById("new_contact").value = ""; //clear input
        }
        else {
            document.getElementById("reponse_new_contact").innerHTML = "mail incorrect";
            console.log("nouvelle relation refusee");
        }
    })
    .catch(erreur => console.log(erreur));
}

function affiche_con_ins(etat) { // pour afficher l'interface de connexion ou d'inscription
    let co = etat == 'ins' ? "none" : "block";
    let ins = etat == 'co' ? "none" : "block";
    document.getElementById("co").style.display = co;
    document.getElementById("ins").style.display = ins;
}

function remove_contact(relation) {
    fetch('https://trankillprojets.fr/wal/wal.php?delier&identifiant='+id+'&relation='+relation.split("_")[1])
    .then(response => response.json())
    .then(json => {
        // {"etat" : { "reponse" : 1, "message" : "suppression association OK"}}
        if (json.etat.reponse) {
            document.getElementById(relation).style.display = "none"; // n'affiche plus la relation supprimée
            console.log("la relation " + relation.split("_")[1] + " a été supprimé");
        }
    })
    .catch(erreur => console.log(erreur));
}

function affiche_contact() {
    fetch("https://trankillprojets.fr/wal/wal.php?relations&identifiant="+id)
    .then(response => response.json())
    .then(json => {
        // {"etat" : { "reponse" : 1, "message" : "liste des relations"},"relations": [{"relation": XX, "identite": "..."}, ...]}
        setTimeout("affiche_contact()",5000); //toute les 5 secondes
        document.getElementById("list_contacts").innerHTML = "";
        if (json.etat.reponse) {
            let div = document.createElement('div');
            let contact = document.createElement("span");
            contact.setAttribute("style","cursor : pointer");
            div.setAttribute("class","message");
            let remove_contact = document.createElement("button");
            remove_contact.innerHTML = "supprimer";
            relation_contacts = [];
            pseudo_contacts = []; // pr actualiser en cas de suppression ou d'ajout de contacts
            let relation_contact,identite_contact;
            div.appendChild(contact);
            div.appendChild(remove_contact); 
            /* stocker l'identifiant et l'identite de la relation, ça consomme de l'espace memoire en plus 
               mais c plus lisible que de passe par le json a chaque fois */
            for (let i = 0;i<json.relations.length;i++) {
                relation_contact = json.relations[i].relation;
                identite_contact = json.relations[i].identite;

                remove_contact.setAttribute("onclick",'remove_contact("contact_'+relation_contact+'")'); // pour effacer un contact   
                div.setAttribute("id","contact_"+relation_contact);
                contact.setAttribute("onclick","affiche_message("+relation_contact+");change_relation("+relation_contact+")");
                contact.innerHTML = identite_contact + " "; 
                document.getElementById("list_contacts").appendChild(div.cloneNode(true)); 
                pseudo_contacts.push(identite_contact); // pour stocker les identites des relations
                relation_contacts.push(relation_contact); // pour stocker les id des relations  
            }
            if (!discussion_initialise){ // test si elle n'ont pas été initiser
                init_discussion(relation_contacts,pseudo_contacts); // initialise les div qui contiendront les discussions
                discussion_initialise = true;
            }
            else{
                actualise_discussion(); // actualise les balise discussion
            }
            // console.log("affiche_contact \npseudo contacts : "+pseudo_contacts + "\nid contacts : "+relation_contacts);
        }
    })
    .catch(erreur => console.log(erreur));
    
}


function affiche_message() {
    fetch('https://trankillprojets.fr/wal/wal.php?lire&identifiant='+id+'&relation='+id_relation)
    .then(response => response.json())
    .then(json => {
        // {"etat" : { "reponse" : 1, "message" : "discussion"},"messages": [{"identite" : "...","message" : "..."}, ...]}
        setTimeout("affiche_message('"+id_relation+"')",2000); // actualise toutes les 2 secondes 
        if (json.etat.reponse) {
            let balise = document.createElement("div");
            let message = document.createElement("div");
            let date_message = document.createElement("div");
            let class_message;
            balise.appendChild(message);
            balise.appendChild(date_message);
            date_message.setAttribute("class","date");
            let txt,date_envoie;
            for (let i = 0; i<json.messages.length; i++) {
                txt = json.messages[i].message.split(";/;/;")[0]; // le message
                date_envoie = json.messages[i].message.split(";/;/;")[1]; // la date et l'heure de son envoie
                class_message = (json.messages[i].identite == pseudo) ? "message_utilisateur" : "message_contact" ;
                balise.setAttribute("class",class_message);
                message.innerHTML = txt;
                date_message.innerHTML = date_envoie;
                document.getElementById("discussion_"+id_relation).appendChild(balise.cloneNode(true));
            }
        }
    })
    .catch(erreur => console.log(erreur));
}


function send_message() {
        // affiche_contact s'occupera de changer id_relation
        let message = document.getElementById("message").value; // input ou il y aura le message
        let date = new Date();
        let date_envoie = "envoyé le " + add_zero(date.getDate()) + "/" + add_zero(date.getMonth()+1) + " à " + add_zero(date.getHours())+ ":" + add_zero(date.getMinutes());
        // getMonth() renvoie un chiffre entre 0 et 11 corrrespondant au mois
        message += ";/;/;" + date_envoie; 
        //j'ai essayer avec une liste, mais elle est convertie en string dans le json
        // du coup je met une suite de charactere que l'utilisateur a peu de chance d'utiliser comme separateur
        console.log(message);
        fetch("https://trankillprojets.fr/wal/wal.php?ecrire&identifiant="+id+"&relation="+id_relation+"&message="+message)
        .then(response => response.json())
        .then(json => {
            // {"etat" : { "reponse" : 1, "message" : "message OK"}}
            if (json.etat.reponse){
                console.log("message envoye")
                document.getElementById("message").value = ""; // clear input, faut mettre value et pas innerHTML, vu que c un balise orpheline je suppose 
                // pb, quand il y a long mot sans espace qui depasse la taille de la div , il sort de la balise
                // avec word-break : break-all, ça force un saut a la ligne
                affiche_message();
            }
            else {
                console.log("message non envoye")
            }
        })
        .catch(erreur => console.log(erreur));
}

function init_discussion(relations,pseudos){ // initialisation des divs qui contiendront les discussions
    let div = document.createElement("div");
    let nom = document.createElement("h3");
    nom.setAttribute("style","text-align : center")
    div.appendChild(nom);
    for (let i = 0;i<relations.length;i++){
        if (relations[i] != undefined){    
            nom.innerHTML = pseudos[i];
            div.id = "discussion_"+relations[i];
            div.style.display = "none";
            id_discussions.push(relations[i]); // stock les discussion initialisée
            document.getElementById("discussion").appendChild(div.cloneNode(true));
        }
    }
}

function change_relation(relation) { // change id_relation + div discussion actuelle
    id_relation = (id_relation == undefined) ? relation : id_relation; // initialise id_relation
    document.getElementById("discussion_"+id_relation).style.display = "none";
    id_relation = relation; 
    document.getElementById("discussion_"+id_relation).style.display = "block";
    console.log("discussion actuelle : "+id_relation);
    affiche_message(); // pour afficher la discussions associée a la relation
}

function add_zero(i) { // pour l'affichage de l'heure et de la date
    if (i>0 && i<10){
        return "0"+i;
    }
    return i;
}

function actualise_discussion(){ // pour creer une discussion pour les nouveaux contacts (apres la connexion)
    let correspond; // index d'un attribut appartenant a relation_contacts et id_discussion
    let correspondance = []; // pour stocker les discussions dont le relation n'as pas été supprimé
    for(let j =0;j<relation_contacts.length;j++){
        correspond = id_discussions.findIndex(e => e == relation_contacts[j]);
        if (correspond != -1){
            correspondance.push(relation_contacts[j]);
            delete relation_contacts[j]; // supprime les relations qui ont une discussion
            delete pseudo_contacts[j];
            // il reste celle qui on ete creer mais qui ne possedent pas de fenetre discussion
        }
    }
    id_discussions = correspondance.slice(); //pour cloner et recuperer les discussion existante et toujours valide
    init_discussion(relation_contacts,pseudo_contacts); // pour initialiser les discussions des nouvelles relations
}