/*
JS | Activité 2
*/

document.querySelector('#jeu').style.visibility='hidden';

var j1 = new Object();
var j2 = new Object();

var current_player;

j1.ins = false;
j2.ins = false;

//Rempli le plateau de pions
function init_plateau() {
	var plateau = document.querySelector('#plateau');
	var pion = document.createElement("div");
	let i;
	pion.className = "pion";	
	// pion.setAttribute("class","pion");
	/* Remplir le plateau */
	for (i = 0; i < 49; i++) {
		/* Remplir le plateau des balises div ayant la class pion -> <div class="pion"></div> */
		pion.id = i;
		pion.setAttribute("onclick","touch("+i+")");
		plateau.appendChild(pion.cloneNode(false));
	}
	document.querySelector('#jeu').style.visibility = 'visible';
}


//Fontion d'inscription
function ins(player) {

	// Completer pour vérifier l'inscription
	if (player==1) {
		j1.ins = true;
		var x = document.getElementsByName('j1');
		x = x[0];
		/* Mettre le nom du joueur dans la balise #j1-name */
		document.querySelector("#j1-name").innerHTML = x.value;
		x.disabled = true;
	}
	else{
		j2.ins = true;
		var x = document.getElementsByName('j2');
		x = x[0];
		/* Mettre le nom du joueur dans la balise #j2-name */
		document.querySelector("#j2-name").innerHTML = x.value;
		x.disabled = true;
	}

	if (j1.ins && j2.ins) {

		// Retirer le panneau d'inscription
		var ins = document.getElementById('ins');
		/* retirer la balise div #ins du html */
		ins.style.display = "none";

		//Initialise le plateau
		init_plateau();

		//lien avec les logo
		j1.logo = document.querySelector('.fas.fa-user.j1');
		j2.logo = document.querySelector('.fas.fa-user.j2');

		//Instruction de jeu
		/* Mettre le nom du joueur dans la balise player-name */
		document.querySelector("#player-name").innerHTML = x.value;
		//ne joue pas pour le moment
		j2.logo.classList.toggle("fas");
		j2.logo.classList.toggle("far");

		current_player = (x.value == document.querySelector("#j1-name").innerHTML)? 1 : 2 ; 
		// initialiastion current_player
	}
}
var compteur_coup = 0;
var fin_partie = false; 
function touch(id){
	var pions = document.querySelectorAll('.pion');
	var col = id % 7; // pour connaitre la colone 
	let pion; 
	var color = (current_player == 1)? "blue" : "red" ;	
	var name = document.querySelector("#j"+ current_player +"-name").innerHTML;
	let current_player_play = false;

	if (fin_partie) {
		return;
	}

	for (let ligne = 0;ligne<=6;ligne++) {
		if (pions[(49 - 7 + col) - 7*ligne].style.background  == "") {
			// pions[(49 - 7 + col) - 7*ligne pour voir etudier la collone du bas vers le haut
			// (49 - 7 + col) pour partir du bas du tableau et - 7*ligne pour remonter
			pions[(49 - 7 + col) - 7*ligne ].style.background = color; // mettre la couleur du joueur
			current_player_play = true; // le joueur a joué
			compteur_coup ++;
			pion = (49 - 7 + col) - 7*ligne; // conserve localisation pion modifier
			break;
		}
	}

	if (compteur_coup == 49) { // cas match nul 
		document.getElementById("info").innerHTML = "Match nul";
		return;
	}

	/* TEST VICTOIRE
	 faut des conditions supplementaire pour eviter des probleme en bord de plateau
	 id = 7*ligne + collone => ligne = (id - collone)/7
	 collone = id%7
	 condition sur diagonale pour bord de tableau : ne doit pas etre sur la meme ligne que le point precedent
	*/
	var ligne = (pion - col)/7;  
	var vert = [0,0,0,true,0,0,0]; // pour tester la continuité c mieux le array
	var hori = [true,0,0,0];
	var diag_d = [0,0,0,true,0,0,0];
	var diag_g = [0,0,0,true,0,0,0];
	for (let n = 1 ; n <= 3 ; n++) { 
		//test  horizontal		
		let hori_p  =(pion + 7*n <= 48)? pion + 7*n : pion; // empeche out range
		if (pions[hori_p].style.background == color && hori_p != pion && col == hori_p%7  ) { // pion sur la meme collone
			hori[n] = true;
		}

		// test vertical 
		let vert_p = (pion + n <= 48)? pion + n : pion;
		let vert_m = (pion - n >= 0)? pion - n : pion;
		if (pions[vert_p].style.background == color && vert_p != pion && ligne == Ligne(vert_p)) { //pion sur la meme ligne
			vert[3 + n] = true;
		} 
		if (pions[vert_m].style.background == color && vert_m != pion && ligne == Ligne(vert_m)) {
			vert[3 - n] = true;
		}

		// test diagonale droite
		let diag_d_p = (pion + 6*n <= 48)? pion + 6*n : pion;
		let diag_d_m = (pion - 6*n >= 0)? pion - 6*n : pion;
		if (pions[diag_d_p].style.background == color && diag_d_p != pion && Ligne(diag_d_p - 6) != Ligne(diag_d_p)) {
			// il faut qu'il ne soit pas sur la meme ligne que le precedent (j'aurais pu le faire avec les collones)
			diag_d[3 + n] = true; 
		} 
		if (pions[diag_d_m].style.background == color && diag_d_m != pion && Ligne(diag_d_m + 6) != Ligne(diag_d_m)) {
			diag_d[3 - n] = true; 
		}
		
		//test diagonale gauche
		let diag_g_p = (pion + 8*n <= 48)? pion + 8*n : pion;
		let diag_g_m = (pion - 8*n >= 0)? pion - 8*n : pion;
		if (pions[diag_g_p].style.background == color && diag_g_p != pion && Ligne(diag_g_p - 8) != Ligne(diag_g_p)) {
			diag_g[3 + n] = true; 
		} 
		if (pions[diag_g_m].style.background == color && diag_g_m != pion && Ligne(diag_g_m + 8) != Ligne(diag_g_m)) {
			diag_g[3 - n] = true; 
		}
		
	}

	var win = [vert,hori,diag_g,diag_d];
	for (let i = 0;i<=3;i++) {
		let taille_liste = win[i].length;
		let compteur = 0;
		for (let j =0 ;j <= taille_liste; j++) {
			
			if (win[i][j] == true) { // test continuité
				compteur ++;
			}
			else if (compteur < 4) { // pour ne pas remettre a zero un compteur a gagnant
				compteur = 0;
			}
		}
		if (compteur >= 4) {
			document.getElementById("info").innerHTML = "Bravo " + name + ", vous avez gagne.";
			document.getElementById("info").appendChild(document.createElement("br"));
			document.getElementById("info").innerHTML += "Redemarrez la page pour rejouer"
			fin_partie = true;
			return;
		}
	}
	
	if (current_player_play == true) {current_player = current_player == 1 ? 2 : 1; } //changement de joueur
	name = document.querySelector("#j"+ current_player +"-name").innerHTML; 
	document.querySelector("#player-name").innerHTML = name; // affichage du prochain joueur
	
}

	// changer le tour du joueur
	// quand je place un pion ds une colone regarder si il y en a deja pour savoir a quel ligne je le place
	// test victoire (verification verticale,horizontale et en diagonale) 
	// + match nul (quand il ne reste plus de place) mettre compteur coups 

function Ligne(n) {
	return ((n-n%7)/7);
}